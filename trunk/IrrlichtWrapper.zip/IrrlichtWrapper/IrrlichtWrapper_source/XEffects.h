#ifndef H_XEFFECTS_ALL
#define H_XEFFECTS_ALL

#include "CShaderPre.h"
#include "CScreenQuad.h"
#include "EffectHandler.h"

#endif

// Copyright (C) 2007-2009 Ahmed Hilali
